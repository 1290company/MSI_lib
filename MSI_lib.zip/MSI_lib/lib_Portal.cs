﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSI_lib
{
    public class lib_Portal
    {
        public static List<T> MarginPirce<T>(List<T> _obj) {

            return _obj;
        }
    }
}
