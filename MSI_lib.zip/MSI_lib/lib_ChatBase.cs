﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSI_lib
{
  public abstract  class lib_ChatBase
    {
        public abstract String FunctionName();
        public abstract String Init(string o);

    }
}
